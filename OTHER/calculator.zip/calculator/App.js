import logo from './logo.svg';
import './App.css';
import {useState} from 'react';
//import Numbers from "./components/numbers";


function App() {
  const [calc, setCalc] = useState("");
  const [setResult] = useState("");

  const functions = ['+', '-', '*', '/'];

  const updatecalc = value => {
    if (
      functions.includes(value) && calc === '' ||
      functions.includes(value) && functions.includes(calc.slice(-1))
    ) {
      return;
    }

    setCalc(calc +value);
    if (!functions.includes(value)) {
      setResult(eval(calc + value).toString());
    }

    const equals = () => {
      setCalc(eval(calc).toString());
    }
  } 

  return (
    <div className="App">
      <div className='calculate'>
        {calc || "0"}
      <div className='clear'>
      <button 
               className="btn ttn-secondary btn-sm"
              
               >
                   CLS
               </button>
      </div>
      <div className="func">
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('+')}
               >
                   +
               </button>
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('-')}
               >
                   -
               </button>
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('*')}
               >
                   x
               </button>
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('/')}
               >
                   /
               </button>
          </div>
        <div className="operators">
               
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('0')}
               >
                   0
               </button>
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('.')}
               >
                   .
               </button>
               <button 
               className="btn ttn-secondary btn-sm"
               >
                   =
               </button>
          </div>
          <div className="numbers">
            <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('1')}
               >
                   1
               </button>
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('2')}
               >
                   2
               </button>
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('3')}
               >
                   3
               </button>
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('4')}
               >
                   4
               </button>
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('5')}
               >
                   5
               </button>
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('6')}
               >
                   6
               </button>
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('7')}
               >
                   7
               </button>
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('8')}
               >
                   8
               </button>
               <button 
               className="btn ttn-secondary btn-sm"
               onClick={() => updatecalc('9')}
               >
                   9
               </button>
        </div>
      </div>  
    </div>
  );
}

export default App;
