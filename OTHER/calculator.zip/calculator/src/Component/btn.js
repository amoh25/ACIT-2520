import { render } from "@testing-library/react";
import react, { Component } from "react";
import "./btn.css"

class btn extends Component{
render(){
    return(    
        <div className="btns">
                <div id="row 1">
                    <button name="AC" onClick={this.props.ClickHandler} value={"AC"}>AC</button>
                    <button name="CE" onClick={this.props.ClickHandler} value={"CE"}>CE</button>
                    <button name="%" onClick={this.props.ClickHandler} value={"%"}>%</button>
                    <button name="÷" onClick={this.props.ClickHandler} value={"÷"}>÷</button>
                </div>
                <div id="row2">
                    <button name="7" onClick={this.props.ClickHandler} value={"7"}>7</button>
                    <button name="8" onClick={this.props.ClickHandler} value={"8"}>8</button>
                    <button name="9" onClick={this.props.ClickHandler} value={"9"}>9</button>
                    <button name="X" onClick={this.props.ClickHandler} value={"*"}>X</button>   
                </div>
                <div id="row3">
                    <button name="4" onClick={this.props.ClickHandler} value={"4"}>4</button>
                    <button name="5" onClick={this.props.ClickHandler} value={"5"}>5</button>
                    <button name="6" onClick={this.props.ClickHandler} value={"6"}>6</button>
                    <button name="-" onClick={this.props.ClickHandler} value={"-"}>-</button>                       
                </div>
                <div id="row4">
                    <button name="1" onClick={this.props.ClickHandler} value={"1"}>1</button>
                    <button name="2" onClick={this.props.ClickHandler} value={"2"}>2</button>
                    <button name="3" onClick={this.props.ClickHandler} value={"3"}>3</button>
                    <button name="+" onClick={this.props.ClickHandler} value={"+"}>+</button>     
                </div>
                <div id="row5">
                    <button name="0" onClick={this.props.ClickHandler} value={"0"}>0</button>
                    <button name=" " > </button>
                    <button name="." onClick={this.props.ClickHandler} value={"."}>.</button>
                    <button name="="onClick={this.props.ClickHandler} value={"="}>=</button>     
                </div>

        </div>
    );
}
}

export default btn