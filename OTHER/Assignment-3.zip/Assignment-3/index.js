let express = require("express");
let app = express();
let server = require("http").createServer(app)

app.get("/",(request, response) => {
    response.sendFile(__dirname + "/index.html")
})

app.get("/courses.js",(request, response) => {
    response.sendFile(__dirname + "/courses.js")
})

app.get("/json",(request, response) => {
    response.sendFile("/courses.json")
})

app.listen(8081)
console.log("listening on port 8081")