var data = require('./courses.json');
var courses = [];
function json_organizer(file) {
    if (file === void 0) { file = data; }
    var obj = JSON.parse(JSON.stringify(file));
    for (var i = 0; i < 8; i++) {
        var one_class = {
            name: obj[i]["course_name"],
            number: obj[i]["course_number"],
            Description: obj[i]["Description"],
            credits: obj[i]["credits"],
            Prerequisites: obj[i]["Pre-requisites"]
        };
        courses.push(one_class);
    }
    ;
}
function table_filler(data) {
    if (data === void 0) { data = courses; }
    for (var i = 0; i < 8; i++) {
        document.getElementById('table').innerHTML += "<tr><td>".concat(data[i].number, "</td><td>").concat(data[i].name, "</td><td>").concat(data[i].Description, "</td><td>").concat(data[i].credits, "</td><td>").concat(data[i].Prerequisites, "</td></tr>");
    }
}
json_organizer();
table_filler();
