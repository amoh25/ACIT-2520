let express = require("express");
let app = express();
let server = require("http").createServer(app)

app.get("/",(request, response) => {
    response.sendFile(__dirname + "/index.html")
})

app.get("/details",(request, response) => {
    response.sendFile(__dirname + "/details.json")
})

app.listen(8081)